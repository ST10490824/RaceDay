﻿
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;

namespace RaceDay.Web.Controllers
{
    public class OrganizerController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public OrganizerController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult CreateEvent()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateEvent(
            string Name,
            string? Description,
            string EventType,
            DateTime EventDate,
            string Location,
            string? RouteInformation)
        {
            var newEvent = new
            {
                OrganizerID = 2,
                Name,
                Description,
                EventType,
                EventDate,
                Location,
                RouteInformation
            };

            var client = _httpClientFactory.CreateClient("RaceDayAPI");

            var response = await client.PostAsJsonAsync(
                "api/events", newEvent);

            if (response.IsSuccessStatusCode)
            {
                TempData["Success"] = "Event created successfully!";
                return RedirectToAction("Index");
            }

            ModelState.AddModelError(
                "",
                "Unable to create event. Please try again."
            );

            return View();
        }
    }
}
